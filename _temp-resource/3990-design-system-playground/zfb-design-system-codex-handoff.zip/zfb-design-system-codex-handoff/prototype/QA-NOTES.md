# Round 2 verification

Reviewed 2026-10-07. This record covers the functional prototype, generated artifacts, and source research. It does not certify a production ZFB documentation build.

## Browser verification

The prototype was served through Vite and inspected in Chromium at the internal preview URL. The production preview is published separately through the hosting service.

| Area | Observed result |
| --- | --- |
| Playground index | New design-system entry is prominent; the four Markdown tools remain available. The index keeps the normal docs content cap. |
| Direct workshop route | `/docs/playground/design-system/` loads the workshop with the docs header, breadcrumb and page title. |
| Editing | Switching to Editorial and setting the accent to `#963142` updates the rendered specimen, edited-decision count, and contrast readout. |
| Specimens | Page, Components and Foundations switch their iframe content. Phone width reports `390 px max`; Wide restores the available width. |
| Role inspection | Selecting the body text in the rendered example reveals the `17px / 1.8` value, `--ds-font-body` role and `text-body` usage. |
| Starter isolation | Enabling inspection in Playground does not add inspection mode to Starter. The starter's journal link stays inside the specimen and leaves the host route unchanged. |
| Export and clipboard | The modal shows all five current files. Copying `design-system.css` places the customized `--ds-brand: #963142` declaration on the clipboard. |
| Host navigation | Returning to the Playground index removes all workshop child nodes. Browser Back remounts one workshop with Editorial and `#963142` restored. |
| Search and mobile navigation | Searching for `design` finds the workshop and related pages. The phone navigation drawer opens the workshop and closes after navigation. Search is explicitly limited to the prototype's small page list. |
| Documentation appearance | Light/Dark/System controls affect documentation and editor chrome. In dark docs, the Editorial specimen remains `rgb(250, 248, 242)` with accent `#963142`. |
| Responsive layout | In 390px and 768px iframe viewports, both index/start and editor layouts fit without horizontal page overflow. With the 15px scrollbar, measured document widths and scroll widths were 375/375 and 753/753. |
| Runtime diagnostics | No application warnings or errors appeared in the captured desktop and responsive preview logs. |

Review fixes included root-scoped lifecycle cleanup, preventing inspection state from leaking into Starter, guarding clipboard completion after disposal, allowing enough room for tablet miniature actions, and removing a one-pixel vertical scroll strip from the mobile tabs.

Screenshots are in `screenshots/`. The responsive fixture is retained as `qa/responsive-fixture.html`; it is excluded from published assets. To reuse it, temporarily copy it into `source/dist/` and visit that path through the development server.

## Export verification

The seed validation scripts extract the pure definitions from the actual `mountDesignWorkshop` body. They do not provide DOM mocks or maintain a second exporter.

Verified workshop source SHA-256:

`c9792a1935307ed5afa5e72328aa8d8f37e3b5dea7a68a4bed6b5815ca3d3edb`

All three seed ZIPs passed CRC checks. All 15 entries decode as UTF-8 and equal the corresponding generated files byte for byte. Standalone specimen scripts have valid syntax and correctly closed script tags. Inspection mode does not change exported standalone documents. See `seeds/node-validation.json` and `seeds/zip-validation.json`.

The complete single-file workshop also passes HTML/script packaging checks: three inline stylesheets, two syntactically valid inline scripts, and no external scripts. Source scripts pass Node syntax checks. See `qa/package-check.json`.

## Practical limits

- The documentation shell is authored HTML/CSS/JavaScript that models the inspected ZFB/zudo-doc layout. It is not the actual ZFB docs build.
- Production Preact hydration, MDX registration, dynamic-page navigation and the proposed native CSS imports have not been built or typechecked. The integration guide identifies the real source paths and remaining checks.
- The preview uses authored CSS. The current zudo-wind export contract was checked against source, but the Rust compiler has not been executed.
- The browser's final ZIP download handoff was not used as evidence. Archive contents were verified directly from the actual exporter; those ready-made ZIPs are included.
- Workshop controls are English. Example content is bilingual; EN/JA documentation drafts are included, but full UI localization remains future work.
- Edited state is retained only while navigating within this prototype session. Use exports to retain a design independently. The standalone file supports its own navigation but does not create browser-history entries under `file://`.
- The initializer remains a reviewable concept. This round does not add a real initializer preset option or change production starter templates.
