# Proposed ZFB documentation integration — round 2

This is a source-backed integration proposal, not an implemented or built change to the ZFB repository. The round-2 review site keeps the accepted workshop and demonstrates how it sits inside a compact documentation shell. Production ZFB documentation would supply its own shell.

## Source and runtime boundary

Reviewed ZFB main: **09a9f9b38f2aae922ebd32128fcfb9a603ba7318**. Its documentation host still pins zfb/runtime/md-wasm/adapter **2.20.2**, zudo-doc **5.27.0**, and Preact **10.29.1**. Follow that host's Preact island integration. The workshop's exported seed targets current zudo-wind; it does not require migrating the documentation host.

Compared with the round-1 ZFB snapshot `622246ca0ea5cf4655929a27cb3cbabe1cda8e2b`, these files have identical Git blob hashes: Rust `zudo-wind/src/config.rs` and `tokens.rs`, TypeScript `packages/zfb/src/config.ts`, and both wind configuration/token guides. No observed schema change invalidates the existing seed shape. This is source verification; the zudo-wind compiler was not run.

## 1. Add a normal wide document page

Proposed paths:

- `docs/src/content/docs/playground/design-system.mdx` → `/docs/playground/design-system/`
- `docs/src/content/docs-ja/playground/design-system.mdx` → `/ja/docs/playground/design-system/`

### English page

```mdx
---
title: Design System Playground
description: Choose a starting design, explore its decisions, and export a project-owned zudo-wind seed.
sidebar_position: 5
wide: true
hide_sidebar: true
hide_toc: true
---

Choose a starting design and adjust its color, typography, spacing, and shape.
See the same decisions in a page, components, and foundations, then take the
editable files into your project.

<DesignSystemPlayground />

The preview uses authored CSS with the same variables as the exported seed.
Run your project's ZFB build to compile and validate the exported utility usage.
For the configuration contract, see [zudo-wind tokens](../zudo-wind/tokens.mdx).
```

### Japanese page

```mdx
---
title: デザインシステム プレイグラウンド
description: 出発点となるデザインを選び、ルールを試しながら、プロジェクトで編集できる zudo-wind のひな形を作れます。
sidebar_position: 5
wide: true
hide_sidebar: true
hide_toc: true
---

出発点となるデザインを選び、色・文字・余白・形のルールを調整できます。
同じルールがページ、コンポーネント、基礎となる値にどう反映されるかを確かめ、
編集できるファイルとしてプロジェクトに持ち帰ってください。

<DesignSystemPlayground />

プレビューは、書き出すひな形と同じ CSS 変数を使った作例です。
書き出したユーティリティの生成と検証は、利用先プロジェクトの ZFB ビルドで行います。
設定の仕様は [zudo-wind のトークン](../zudo-wind/tokens.mdx) を参照してください。
```

The component currently has English controls and bilingual example content. These drafts localize the surrounding documentation; they do not claim that every workshop control has been translated.

No new h1 belongs inside the embedded component. zudo-doc renders the page title from frontmatter. The new page adopts the same `wide` / hide-rails flags as the existing render/compile/parse/highlight pages.

The current Playground **index** has `hide_sidebar: true` and `hide_toc: true`, but no `wide: true`. At typical desktop widths its 80rem cap already fills most of the screen. Preserve that index policy unless a wider index is an explicit design choice.

## 2. Update the index wording in both locales

The existing index says every playground runs the Rust pipeline. The design workshop uses authored CSS, so that blanket description must change.

### English index draft

```mdx
---
title: Playground
description: Interactive browser tools for ZFB content and design.
sidebar_position: 35
hide_sidebar: true
hide_toc: true
---

Explore ZFB's content pipeline and design tools in the browser. The Markdown
playgrounds run the Rust pipeline; the Design System Playground lets you shape
a project-owned visual language and export an editable starting point.

<CategoryNav category="playground" />
```

### Japanese index draft

```mdx
---
title: Playground
description: ZFB のコンテンツ処理とデザインをブラウザで試せるツールです。
sidebar_position: 35
hide_sidebar: true
hide_toc: true
---

ZFB のコンテンツ処理とデザインをブラウザで試せます。
Markdown の各プレイグラウンドでは Rust の処理パイプラインを実行します。
デザインシステム プレイグラウンドでは、プロジェクトで使う見た目のルールを作り、
編集できるひな形として書き出せます。

<CategoryNav category="playground" />
```

`CategoryNav` reads the category's child content. Add the corresponding header submenu entry in `docs/zfb.config.ts`, keeping the current Index and four Markdown playground items:

```ts
{ label: "Design System", path: "/docs/playground/design-system" }
```

## 3. Adapt the actual mountable app into a browser module

The review artifact is separated into:

- `source/dist/workshop.js`: markup, model, export functions, root-scoped mount and lifecycle.
- `source/dist/workshop.css`: scoped workshop styles.
- `source/dist/workshop-adapter.css`: documentation-theme adapter.
- `docs-shell.js` and `docs-shell.css`: review-site shell only.

Copy the first three files into a host-owned directory such as:

`docs/src/components/playground/design-workshop/`

Do not copy the review site's shell or its parallel HTML routes into production docs.

The current review script exposes `window.mountDesignWorkshop`. For the host's module copy, make its module boundary explicit:

```diff
-window.mountDesignWorkshop = function mountDesignWorkshop(root, options = {}) {
+export function mountDesignWorkshop(root, options = {}) {
   // Preserve the existing function body.
-};
+}
```

The actual mount returns a handle with `getSnapshot()`, `getSeedFiles()`, `zipBytes()`, `navigate()`, and an idempotent `dispose()`. Its cleanup aborts listeners/tools, clears the toast timer, revokes the export object URL, closes open dialogs, and removes owned DOM. The caller must invoke `dispose()` when the component unmounts. This is especially relevant because ZFB docs enable `dynamicPageTransition`.

## 4. Add the Preact wrapper and MDX binding

Proposed wrapper: `docs/src/components/playground/design-system-playground.tsx`.

```tsx
/** @jsxRuntime automatic */
/** @jsxImportSource preact */
"use client";

import { useEffect, useRef, useState } from "preact/hooks";

// Retained in the client module across docs navigation; not persistent storage.
let savedWorkshop: unknown;

export default function DesignSystemPlayground() {
  const root = useRef<HTMLDivElement>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    let unmounted = false;
    let app: { dispose(): void; getSnapshot(): unknown } | undefined;

    void import("./design-workshop/workshop.js")
      .then(({ mountDesignWorkshop }) => {
        if (unmounted || !root.current) return;
        app = mountDesignWorkshop(root.current, { initialState: savedWorkshop });
      })
      .catch((error: unknown) => {
        if (!unmounted) {
          setLoadError(error instanceof Error ? error.message : String(error));
        }
      });

    return () => {
      unmounted = true;
      if (app) {
        savedWorkshop = app.getSnapshot();
        app.dispose();
      }
    };
  }, []);

  return (
    <section aria-label="Design system playground">
      <div id="design-workshop" ref={root}>
        <p class="text-small text-muted">Loading the design workshop…</p>
      </div>
      {loadError ? <p role="alert" class="text-small text-danger">{loadError}</p> : null}
    </section>
  );
}

DesignSystemPlayground.displayName = "DesignSystemPlayground";
```

The current scoped CSS requires the mount node's `id="design-workshop"`; this proposal mounts one workshop per document page. The preview's `--ds-*` variables remain inside its iframe document. Documentation appearance changes affect the tool controls, while the selected design retains its own palette.

In `docs/src/chrome-bindings.tsx`, mirror the existing four playground wrappers:

```tsx
import DesignSystemPlayground from "./components/playground/design-system-playground";

const DesignSystemPlaygroundIsland = () =>
  Island({ when: "visible", children: <DesignSystemPlayground /> });

// Add to the existing defineChromeBindings({ mdxExtras: { ... } }):
DesignSystemPlayground: DesignSystemPlaygroundIsland,
```

Preserve the existing `homeExtras`, `WindPreviewEnhancer`, and Markdown playground bindings. The config already has:

```ts
chromeBindingsModule: "./src/chrome-bindings.tsx"
```

Both docs route stubs already statically import the bindings module, allowing the island scanner to reach the on-disk client component. No replacement route stub is needed.

Load styles from the existing `docs/src/styles/global.css` entry, after the package CSS imports and before the first style rule:

```css
@import "../components/playground/design-workshop/workshop.css";
@import "../components/playground/design-workshop/workshop-adapter.css";
```

Keep the package order `theme.css` before `features.css`. The wrapper/module and import snippets are proposed integration code; they have not been typechecked or built against the host. The accepted behavior requires snapshot retention across native docs navigation: verify the host keeps this client module alive, or use a host-owned in-memory store if its module lifecycle differs. A hard reload need not preserve the snapshot.

## 5. Preserve native layout and discovery

The pinned zudo-doc 5.27.0 wide content band is:

```css
max-width: clamp(50rem, 92.5vw, 120rem);
```

It remains inside the normal header/breadcrumb/footer. Main horizontal padding is 24px, increasing to 32px on desktop. The workshop should use available content width and `min-width: 0`, rather than impose a second viewport-sized page.

Update the existing `page-title-layout.test.ts` expected header item and page list, and add the new route/marker to `docs/scripts/assert-island-markers.mjs`. Those are existing integration contracts, not optional evidence inferred from the visual prototype. Production verification should establish direct-load hydration and a clean arrival/remount through docs navigation before reporting integration complete.

## Native palette reference

The pinned default light palette is authored in OKLCH. Approximate hex values below are rounded/clipped sRGB conversions, not the source format.

| Role | Native property / alias | Exact source | Approximate hex |
| --- | --- | --- | --- |
| Background | `--zd-bg` / `--color-bg` | `oklch(.965 .004 65)` | `#f5f3f1` |
| Surface | `--zd-surface` / `--color-surface` | `oklch(.965 .004 65)` | `#f5f3f1` |
| Foreground | `--zd-fg` / `--color-fg` | `oklch(.185 .005 65)` | `#141210` |
| Muted | `--zd-muted` / `--color-muted` | `oklch(.480 .008 65)` | `#615d59` |
| Accent | `--zd-accent` / `--color-accent` | `oklch(.470 .120 56)` | `#8c4500` |
| Accent hover | `--zd-accent-hover` / `--color-accent-hover` | `oklch(.400 .096 56)` | `#6d3703` |

The theme also exports scoped `--color-zd-*` aliases for embedded consumers. Use the native properties rather than hardcoding the approximate colors in production. Type roles micro/caption/small/body/title/heading/display resolve to 12/14/16/19.2/22.4/48/60px at a 16px root size.

## Export verification in this package

The baseline archives in `seeds/` were generated from the actual round-2 pure functions, not a separately maintained exporter. To reproduce after placing the source in its package location:

```sh
node validate-seeds.mjs
python validate-zip.py
```

Each script also accepts an optional source path as its first argument. Node extracts only the pure definitions inside the exact mount-function boundaries; no root/document/window mocks are supplied. Python checks all ZIP CRCs, UTF-8 and byte equality against the generated files. The reports also identify the full source SHA.

This verifies export generation and archives. It does not run the ZFB compiler or prove the native docs integration has been built.

## Source references

- [ZFB docs dependencies](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/package.json)
- [Existing wide playground MDX](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/content/docs/playground/render.mdx)
- [Playground index](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/content/docs/playground/index.mdx)
- [Current chrome bindings](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/chrome-bindings.tsx)
- [Bindings config and header navigation](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/zfb.config.ts)
- [Existing client component pattern](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/components/playground/render-playground.tsx)
- [Native wide layout](https://github.com/zudolab/zudo-doc/blob/v5.27.0/packages/zudo-doc/src/features.css#L329-L355)
- [Native theme roles](https://github.com/zudolab/zudo-doc/blob/v5.27.0/packages/zudo-doc/src/theme.css)
- [Native color ramps and mode mapping](https://github.com/zudolab/zudo-doc/blob/v5.27.0/packages/zudo-doc/src/color-schemes-defaults/index.ts)
- [External mount precedent](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/src/components/diagram-workbench.tsx)

