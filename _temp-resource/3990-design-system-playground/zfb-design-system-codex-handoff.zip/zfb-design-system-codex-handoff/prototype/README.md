# ZFB design-system playground — round 2

Round 2 places the accepted workshop concept inside a ZFB documentation experience. The documentation header, breadcrumbs, wide content region, and tool styling show how it could feel at home in the docs.

**Review status:** the user accepted round 2 on 2026-10-07: “good. spec locked in.” The accepted behavior is recorded in `../ACCEPTED-SPEC.md`. This is a functional UI prototype with an authored documentation shell, not a production zudo-doc build or completed ZFB integration.

Review site: <https://zfb-design-workshop.takazudo69458.chatgpt.site/>. The workshop route is `/docs/playground/design-system/`; the preserved first round is at `/r1/`.

## Open locally

Open `zfb-design-workshop-r2.html` for the standalone version. Internal page links work within this file. Under `file://`, they do not create browser-history entries; use the page's own navigation to move between views. External documentation links open the real documentation sites.

For the editable development version, run these commands from this review folder:

```sh
cd source
npm ci
npm run dev
```

Open the address printed by Vite. The configured Vite root is `source/dist/`, which contains the editable HTML, styles, and scripts. This development server does not run the ZFB compiler.

## Suggested review path

1. Start at the Playground index and open **Design system**.
2. Compare Everyday, Editorial, and Workbench; choose a seed.
3. Edit values in Playground. Switch Page / Components / Foundations, then use **Inspect roles** to follow a design decision.
4. Change the documentation appearance. The editing interface follows it; the seed preview keeps its own design.
5. Open Starter demo, toggle its notes, and export the current seed.
6. Navigate back to the Playground index, then reopen the workshop. Design and view state are retained across this host navigation within the current session. Download an export to keep a design independently.

## Contents

| Path | Purpose |
| --- | --- |
| `zfb-design-workshop-r2.html` | Standalone interactive review |
| `source/` | Vite project, including the preserved `dist/r1/` version |
| `seeds/` | Everyday, Editorial, and Workbench examples and ZIPs |
| `integration/README.md` | Source-grounded integration guidance and remaining work |
| `screenshots/` | Captures for comparing the reviewed interface |
| `QA-NOTES.md` | Verification evidence and limits |
| `decisions.md` | Accepted, added, superseded, and pending decisions |

Each seed contains `design-system.css`, `zfb.design.ts`, `usage.tsx`, `DESIGN-NOTES.md`, and `demo.html`. These provide project-owned values, a wind configuration section, usage examples, rules, and a standalone specimen. They are not complete ZFB applications.

The preview uses authored CSS. The wind export is source-reviewed only: **neither the actual ZFB compiler nor production zudo-doc hydration has been run**. Use the integration guide for the next implementation step and the QA notes for what this prototype establishes.
