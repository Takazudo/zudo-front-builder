import assert from 'node:assert/strict';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { createHash } from 'node:crypto';

const reviewRoot = path.dirname(fileURLToPath(import.meta.url));
const sourceRelativePath = 'source/dist/workshop.js';
const sourcePath = process.argv[2] ? path.resolve(process.argv[2]) : path.join(reviewRoot, sourceRelativePath);
const outDir = path.join(reviewRoot, 'seeds');
const source = await readFile(sourcePath, 'utf8');
const startMarker = 'window.mountDesignWorkshop = function mountDesignWorkshop(root, options = {}) {';
const endMarker = '\nroot.innerHTML=ZWD_WORKSHOP_MARKUP;';
const start = source.indexOf(startMarker);
const end = source.indexOf(endMarker, start + startMarker.length);
assert(start >= 0 && end > start, 'exact mount-body and DOM-start markers exist');
assert.equal(source.indexOf(startMarker, start + 1), -1, 'mount marker occurs exactly once');
assert.equal(source.indexOf(endMarker, end + 1), -1, 'DOM-start marker occurs exactly once');
const prefix = source.slice(start + startMarker.length, end);
// Evaluate original pure mount-body definitions before the first DOM mutation.
// Nested preview scripts stay unchanged. No root/document/window mocks are provided.
const api = new vm.Script("'use strict';\n(() => {" + prefix + '\nreturn { state, PRESETS, getSeedFiles, zipBytes };\n})();', { filename: 'workshop-pure-definitions.js' })
  .runInNewContext({ Blob, TextEncoder });
await mkdir(outDir, { recursive: true });
const sha256 = data => createHash('sha256').update(data).digest('hex');
const requiredFiles = ['zfb.design.ts', 'design-system.css', 'usage.tsx', 'DESIGN-NOTES.md', 'demo.html'];
const report = {
  sourcePath: sourceRelativePath,
  sourceReadFrom: sourcePath,
  sourceSha256: sha256(source),
  nodeVersion: process.version,
  evaluatedPrefixBytes: Buffer.byteLength(prefix),
  noDomStubs: true,
  zfbCompilerExecuted: false,
  presets: [],
};
for (const [id, preset] of Object.entries(api.PRESETS)) {
  api.state.preset = id;
  api.state.values = { ...preset.values };
  api.state.inspect = false;
  const files = api.getSeedFiles();
  api.state.inspect = true;
  assert.equal(api.getSeedFiles()['demo.html'], files['demo.html'], 'exported demo is independent of editor inspection mode');
  api.state.inspect = false;
  assert.deepEqual(Object.keys(files).sort(), [...requiredFiles].sort());
  const folder = path.join(outDir, id);
  await mkdir(folder, { recursive: true });
  for (const [filename, text] of Object.entries(files)) {
    assert.equal(typeof text, 'string');
    assert(!text.includes('\ufffd'), `${id}/${filename}: no Unicode replacement character`);
    assert.equal(new TextDecoder('utf-8', { fatal: true }).decode(new TextEncoder().encode(text)), text);
    await writeFile(path.join(folder, filename), text, 'utf8');
  }
  const configMatch = files['zfb.design.ts'].match(/export const wind = ([\s\S]+) as const;\s*$/);
  assert(configMatch, `${id}: typed literal export retained`);
  const config = JSON.parse(configMatch[1]);
  assert.equal(config.spec, 1);
  assert.equal(config.reset, 'owned-v1');
  assert.equal(config.breakpoints.wide.minWidthPx, 960);
  assert(!Object.hasOwn(config.tokens, 'spacingUnit'), 'no implicit numeric spacing');
  for (const [a, b] of [['colors', 'fontSizes'], ['spacing', 'sizes'], ['fontFamilies', 'fontWeights']]) {
    assert(!Object.keys(config.tokens[a]).some(name => name in config.tokens[b]), `${id}: disjoint ${a}/${b} names`);
  }
  const css = files['design-system.css'];
  const variables = Object.fromEntries([...css.matchAll(/^\s*(--ds-[a-z-]+):\s*(.+);$/gm)].map(m => [m[1], m[2]]));
  const expected = {
    '--ds-brand': preset.values.accent,
    '--ds-background': preset.values.background,
    '--ds-surface': preset.values.surface,
    '--ds-ink': preset.values.ink,
    '--ds-muted': preset.values.muted,
    '--ds-border': preset.values.border,
    '--ds-type-base': preset.values.bodySize + 'px',
    '--ds-leading-body': String(preset.values.lineHeight),
    '--ds-vsp-stack': preset.values.groupGap + 'px',
    '--ds-vsp-section': preset.values.sectionGap + 'px',
    '--ds-hsp-card': preset.values.horizontalSpace + 'px',
    '--ds-hsp-gutter': preset.values.horizontalGap + 'px',
    '--ds-hsp-page': (preset.values.horizontalSpace + 8) + 'px',
    '--ds-radius-panel': preset.values.radius + 'px',
    '--ds-size-reading': preset.values.readingWidth + 'ch',
  };
  for (const [key, value] of Object.entries(expected)) assert.equal(variables[key], value, `${id}: ${key}`);
  for (const match of (JSON.stringify(config.tokens) + css).matchAll(/var\((--[^), ]+)/g)) {
    assert(!match[1].startsWith('--zw-'), `${id}: token does not reference reserved namespace`);
    assert(Object.hasOwn(variables, match[1]), `${id}: declared variable ${match[1]}`);
  }
  for (const entry of Object.values(config.tokens.fontSizes)) {
    assert.equal(typeof entry, 'object');
    assert.equal(typeof entry.size, 'string');
    assert.equal(typeof entry.lineHeight, 'string');
  }
  assert(!files['usage.tsx'].includes('className='), 'native class attribute used');
  assert(files['usage.tsx'].includes('font-ui'), 'example applies body font family');
  assert(files['usage.tsx'].includes('gap-x-hsp-gutter gap-y-vsp-stack'), 'horizontal/vertical gaps remain independent');
  assert(Object.hasOwn(config.tokens.spacing, 'hsp-gutter'), 'horizontal gap token exists');
  assert(files['zfb.design.ts'].includes(preset.name));
  assert(css.includes(preset.name));
  const notes = files['DESIGN-NOTES.md'];
  assert(notes.startsWith(`# ${preset.name} design seed\n`));
  assert(notes.includes(`${preset.values.groupGap}px within vertical groups and ${preset.values.sectionGap}px between sections`));
  assert(notes.includes(`${preset.values.bodySize}px body text with ${preset.values.lineHeight} line height`));
  assert(notes.includes('compiler has not been executed'));
  assert(notes.includes('Merge token maps by category and then by token name'));
  const html = files['demo.html'];
  assert(html.startsWith('<!doctype html>'));
  assert(html.endsWith('</body></html>'));
  assert(html.includes(`<title>Fieldnotes · ${preset.name}</title>`));
  assert(html.includes('つくること、考えること。'), 'Japanese text preserved');
  const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)];
  assert.equal(scripts.length, 1, 'exactly one properly closed script');
  assert.equal((html.match(/<script\b/gi) || []).length, scripts.length, 'no unmatched script opening');
  assert.equal((html.match(/<\/script\s*>/gi) || []).length, scripts.length, 'no extra script closing');
  for (let n = 0; n < scripts.length; n++) new vm.Script(scripts[n][1], { filename: `${id}/demo-inline-${n}.js` });
  const embeddedVariables = html.match(/<style id="ds-variables">([\s\S]*?)<\/style>/)?.[1];
  assert(embeddedVariables, 'demo embeds variable stylesheet');
  assert(css.endsWith(embeddedVariables), 'standalone demo variables equal stylesheet export');
  const archive = api.zipBytes(files);
  assert(archive instanceof Blob, 'actual archive function returns Blob');
  const bytes = Buffer.from(await archive.arrayBuffer());
  assert.equal(bytes.readUInt32LE(0), 0x04034b50, 'ZIP local-header signature');
  const archiveName = `zudo-wind-${id}-seed.zip`;
  await writeFile(path.join(outDir, archiveName), bytes);
  report.presets.push({
    id,
    name: preset.name,
    values: { ...preset.values },
    zip: archiveName,
    zipBytes: bytes.length,
    zipSha256: sha256(bytes),
    htmlScriptsSyntaxValid: scripts.length,
    utf8RoundtripPassed: true,
    files: requiredFiles.map(name => ({ name, bytes: Buffer.byteLength(files[name]), sha256: sha256(files[name]) })),
  });
}
await writeFile(path.join(outDir, 'node-validation.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ sourceSha256: report.sourceSha256, presets: report.presets.map(p => ({ id: p.id, zipBytes: p.zipBytes, zipSha256: p.zipSha256 })), noDomStubs: true, zfbCompilerExecuted: false }, null, 2));
