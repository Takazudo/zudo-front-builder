// Complete utility-class literals, using this seed's vocabulary.
// Load design-system.css through your existing stylesheet entry.
// Your ZFB build compiles these utility classes when the component is used.
// The demo.html file is
// a separate authored-CSS visual specimen and does not run the compiler.
export function DesignExample() {
  return (
    <section class="font-ui bg-surface text-ink px-hsp-card py-vsp-stack rounded-panel">
      <h2 class="font-display text-section font-strong">Small ideas.</h2>
      <p class="text-body max-w-reading mt-vsp-stack">
        Give the repeated decisions a name.
      </p>
      <div class="flex flex-wrap gap-x-hsp-gutter gap-y-vsp-stack mt-vsp-section">
        <button class="bg-accent text-on-accent px-hsp-card py-vsp-stack rounded-panel">
          Primary action
        </button>
      </div>
    </section>
  );
}
