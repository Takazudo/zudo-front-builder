# Editorial design seed

Generated from zudo-wind Design workshop, prototype round 2.
This is a curated example you own, not an engine default.

## Use these files

1. Open demo.html directly to inspect the design without installing anything.
2. Copy design-system.css into your project and load it through the existing stylesheet entry.
3. Import the wind export from zfb.design.ts into your existing zfb.config.ts and merge deliberately with the current wind section. Keep unrelated configuration, routes, plugins and stylesheet paths.
4. Merge token maps by category and then by token name. Do not replace the entire existing tokens object while existing pages still depend on its values.
5. Copy usage.tsx into your existing component source tree and render it from a page. Run your project's normal ZFB build to compile utilities and validate integration.

The live demo uses authored CSS consuming the same CSS variables. It is a visual specimen, not the result of running zudo-wind. The config shape was source-reviewed at ZFB commit 622246ca0ea5cf4655929a27cb3cbabe1cda8e2b; the compiler has not been executed by this prototype.

## Design decisions

- Use accent for primary actions, selected states and keyboard focus. Keep text, notice borders and supporting content neutral.
- Use square corners for cards, fields and buttons. Keep surfaces flat.
- Use 20px within vertical groups and 56px between sections. Horizontal card padding is 30px; column gutters are independently 20px.
- Use 17px body text with 1.8 line height and a reading measure of 56ch. Headings use serif; the body uses a clear sans-serif.

## What the names mean

- hsp-card and hsp-page: horizontal padding decisions.
- hsp-gutter: independently named horizontal column gaps.
- vsp-stack: vertical space inside a group.
- vsp-section: space between separate groups.
- body, heading, section and caption: font-size roles with explicit line height.
- accent and on-accent: primary-action background and its readable label.
- reading: a bounded text measure.
- panel: the declared corner rule used by cards, inputs and buttons.

A small vocabulary makes repeated decisions visible. Structural one-offs can remain close to their component. Add a new token when it represents a real reusable decision.

## Scope and ownership

These files are standalone project inputs. No dependency on the workshop, styleguide engine or token panel is required. This is not a complete ZFB app: it has no routing, content collection or build scripts. Existing ZFB template selection is separate. No --preset or --design-seed CLI option is claimed here.

The seed includes no light/dark switch; Workbench is a distinct dark seed. Add mode mappings deliberately if your project needs both. The button label color is selected for contrast against the accent, not a claim of whole-page accessibility certification.

## Research sources

- https://github.com/Takazudo/zudo-front-builder
- https://github.com/Takazudo/zudo-css-wisdom
- https://github.com/Takazudo/zudo-sg
- https://github.com/Takazudo/zudo-design-token-panel
