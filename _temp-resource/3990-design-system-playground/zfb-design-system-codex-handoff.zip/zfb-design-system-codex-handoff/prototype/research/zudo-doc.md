# Round 2 — zudo-doc integration research

## Snapshot and evidence boundary

- Requested repository `Takazudo/zudo-doc` returned 404 via the connected GitHub API.
- The requested live page's GitHub/source links point to the current canonical repository **zudolab/zudo-doc**.
- Current main: **337b9f110793dccb4759bddd5273eab38cd9d2f0**, commit date **2026-09-27T21:46:08Z**, message “chore: bump create-zudo-doc to v5.28.2”.
- Package `@takazudo/zudo-doc`: **5.28.2**. Its package peer dependencies require **@takazudo/zfb, zfb-md-wasm and zfb-runtime ^2.22.1**. These findings verify zudo-doc's present source, not compatibility with ZFB v3.
- Read the requested live URL through web browsing, then inspected current source through the GitHub connector. No browser UI, builds, repository writes, deployment or Sites operations performed.
- Web refs available for the parent to open before citing: `turn3view0` (requested wide demo), `turn4view0` (current source page), `turn4view1` (canonical repository).
- Source files inspected are cached under `research-r2/sources/zudo-doc/`.

## 1. What wide actually does

The wide demo's source explicitly combines:

```yaml
hide_sidebar: true
hide_toc: false
wide: true
```

The live guide explains that `hide_sidebar` alone keeps a centered, capped reading column; `wide` removes that narrower cap. It does not implicitly hide a sidebar, TOC, header, breadcrumb, title or footer.

Actual implementation:

- The renderer maps frontmatter `wide` to `DocPageShell.contentWide`, then to `DocLayout.contentWide`.
- `contentWide` emits `data-zd-wide` on `.zd-doc-content-band`.
- Ordinary band maximum: `var(--zdc-content-max-width, clamp(50rem,75vw,90rem))`.
- Sidebar-hidden band maximum: `80rem`.
- Wide band maximum: **`clamp(50rem, 92.5vw, 120rem)`**. Its selectors deliberately beat both the static sidebar-hidden cap and the reader-toggled sidebar-hidden cap.
- The band still has `width:100%`; the 50rem lower value in its max-width expression does not force mobile to a 50rem minimum width.
- Main remains `flex:1; min-width:0` with the normal docs horizontal/vertical padding.
- The global header remains present. Package default header/layout height is 3.5rem; the 80px `--zd-header-h` is an anchor-scroll offset and should not be mistaken for the actual header box.
- The article is always `<article class="zd-content max-w-none">`.

Sources:

- [Wide demo source](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/src/content/docs/guides/layout-demos/wide.mdx)
- [Frontmatter reference](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/src/content/docs/guides/frontmatter.mdx) (hide_sidebar 307+, wide 365+)
- [Renderer mapping](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/doc-page-renderer/index.tsx) (285–321)
- [DocLayout](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/doclayout/doc-layout.tsx) (395–467)
- [features.css](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/features.css) (293–355, 1017–1018)

## 2. Header / sidebar / TOC / mobile relationships

### Desktop

- Sidebar appears at **lg / 1024px**, fixed to the left below the header, with width `--zd-sidebar-w`. Main's outer wrapper carries the corresponding left margin.
- Default desktop TOC appears at **xl / 1280px**, in a `.zd-toc-col.hidden.xl:flex` wrapper. Its default width is `--zdc-toc-width`, fallback 280px.
- Sidebar and TOC are separate decisions. A wide page can retain both, one, or neither.
- `hide_sidebar:true` hides the desktop visual sidebar; current DocLayout retains an sr-only landmark when sidebar content exists. Mobile navigation is still supplied by the header.
- `hide_toc:true` omits both the desktop and mobile TOC.
- A page with no qualifying headings omits the default TOCs.
- Do not use `standalone:true` just to get a wide workshop. It also removes the page from sidebar navigation/site index; that would undermine discovery of /docs/playground/.

### Existing reader controls

- `sidebarToggle:true` enables a desktop sidebar collapse handle; default false.
- `tocToggle:true` enables a right-edge desktop TOC collapse handle at 1280px+; default false.
- The selections persist in localStorage and are restored before paint; html state attributes survive soft navigation.
- Hiding the TOC releases its width and gap to main.
- `tocToggle` only controls the package default TOC. A custom `Toc` binding is deliberately unaffected.
- If an author sets `hide_toc:true`, there is no TOC for a reader toggle to reveal.
- No general page-wide focus/fullscreen mode or `hide_header`/`hide_title` frontmatter API was found in the inspected public configuration, frontmatter, DocLayout or DocPageShell props. A workshop “Expand” mode should be described as new local behavior.

### Mobile

- Header hamburger is available below 1024px independently of the desktop hide-sidebar choice.
- The drawer owns its navigation tree, locks body scroll while open, is inert while closed, closes on navigation/backdrop/Escape and restores focus to the hamburger on Escape.
- Default mobile TOC is an accordion above the article, below 1280px, and closes when a link is selected.
- Mobile preview UI should stack/offer local tabs rather than rely on the desktop TOC or a compressed three-column workbench.

Sources:

- [Layout](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/doclayout/doc-layout.tsx)
- [Page shell](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/doc-page-shell/index.tsx) (282–335)
- [Configuration](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/src/content/docs/guides/configuration.mdx) (735–764)
- [Mobile drawer](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/sidebar-toggle-island/index.tsx)
- [Mobile TOC](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/toc/mobile-toc.tsx)
- [Sidebar toggle](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/desktop-sidebar-toggle-island/index.tsx)
- [TOC toggle](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/desktop-toc-toggle-island/index.tsx)

## 3. Component authoring and hydration — material integration risk

Two supported authoring routes exist:

1. Import a component locally in an MDX file.
2. Register it globally with `defineChromeBindings({ mdxExtras: { MyComponent } })`, then set `chromeBindingsModule: "./src/chrome-bindings.tsx"` in `zudoDoc()`.

**Both are server rendering mechanisms. Neither alone hydrates a component.**

Current custom-components guide labels interactive islands **experimental** and gives this contract:

- Interactive inner component module starts with `"use client";`.
- It must be statically reachable through the route import graph.
- Pin `Component.displayName`.
- Wrap the **bare inner component** with the function call `Island({ when:"load" | "visible", children:<Component /> })`.
- For host components that are only reachable through the virtual chrome-bindings module, explicitly replace the applicable route stub's virtual import with a static import of the real bindings module. Include applicable locale/version route variants.
- The virtual re-export is sufficient for SSR-presentational bindings but does not guarantee island scanner reachability.
- Test actual hydrated behavior in the **built site**, not just the presence of SSR HTML or dev output.

The guide's linked issue #2718 is historical: it reproduced an old next.78/next.87 ZFB line and is now closed as not_planned/superseded by a downstream compatibility cleanup. Its comments explicitly avoid claiming the generic Counter naming defect was fixed. The referenced upstream #1187 is also closed and concerns a particular duplicate ThemeToggle. Therefore the current guide's experimental wording and static-import requirement are verified, but these old issues are **not evidence that current ZFB v3 has the same defect**. Do not present that as a confirmed v3 bug.

The existing `pages/lib/_preset-generator.tsx` demonstrates a statically imported client component with `displayName` and `Island({ when:"load", ssrFallback, children })`. Its fallback renders the generator sections as meaningful HTML. This is a useful structural example, but its current showcase route itself uses the virtual import, and documentation explicitly warns about that scanner gap. Do not infer that copying only the wrapper proves hydration.

The existing `PresetGenerator` name is already used for zudo-doc project setup options (project name, language, color mode, theme pack, features, package manager). Use a new workshop name such as `DesignSystemPlayground` to avoid colliding with the built-in registry entry.

Project-owned scaffold TSX should use **className**, according to the current custom-components guide. Package source sometimes uses `class` under a different Preact compilation boundary.

Sources:

- [Custom Components guide](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/src/content/docs/guides/custom-components.mdx)
- [Host Chrome Bindings](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/src/content/docs/reference/host-chrome-bindings.mdx)
- [Existing generator island/fallback](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/pages/lib/_preset-generator.tsx)
- [Actual current route](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/pages/docs/[[...slug]].tsx)
- [Actual current bindings](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/src/chrome-bindings.tsx)

## 4. Actual slots, and where the workshop belongs

For ordinary MDX content, use per-file imports or `mdxExtras`. The workshop belongs in the document body.

Other verified extension surfaces:

- `docContentHeaderExtras({entry,slug,locale,isFallback,version})` inserts content **between h1 and metainfo**. It is an addition, not a replacement for the whole title/header.
- `headerRightComponents` registers named custom header-right renderers, paired with serializable `headerRightItems` component-name entries.
- `Header`, `Footer`, `Sidebar`, `Toc`, `Breadcrumb`, `DocPager` replace whole primary chrome components through typed host bindings.
- `BodyEndIslands` provides the body-end integration point, with the same scanner-reachability considerations.
- Lower-level `DocLayout` slots include head, header, sidebar, afterSidebar, breadcrumb, afterBreadcrumb, mobileToc, main, afterContent, toc, footer, bodyEndComponents and bodyEndScripts.
- `DocLayoutWithDefaults` offers headerOverride, sidebarOverride, tocOverride, mobileTocOverride, breadcrumbOverride and footerOverride.
- Lower-level `DocPageShell` has contentHeaderSlot and contentSlot, but ordinary package renderDocPage supplies those. These are custom-route APIs, not MDX frontmatter flags.

For r2, keep the existing header/breadcrumb and a compact native page title, then start the workshop. An expanded local workspace should keep a visible return action and restore focus/state when closed, without rewriting global sidebar preferences.

Sources:

- [Typed chrome bindings](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/chrome-bindings.ts)
- [Host bindings guide](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/src/content/docs/reference/host-chrome-bindings.mdx)
- [DocLayout props](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/doclayout/doc-layout.tsx)
- [DocLayoutWithDefaults](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/doclayout/doc-layout-with-defaults.tsx)
- [DocPageShell props](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/doc-page-shell/index.tsx)

## 5. CSS scope and dark-mode ownership

The docs body is `.zd-content`. Its descendant rules reach headings, links, lists, code and other semantic tags inside custom components. Many use `:where()`, but not every rule is zero-specificity, and some component-token rules are intentionally unlayered. No generic `not-prose`/`not-content` exemption was found in the inspected stylesheet.

Therefore:

- Put workshop controls under one unique root and scope explicit UI typography, margins, links and form styles there.
- Use workshop-owned CSS variable names; do not mutate docs root variables or bare `--color-*` names for the generated design.
- For the generated website specimen, use an iframe so its stylesheet/variables cannot restyle docs navigation and the docs content typography cannot contaminate the specimen.
- Keep **site appearance** and **preview appearance** separate. A dark docs shell can show a light selected preset and vice versa.
- Current site mode sets both `html[data-theme="light"|"dark"]` and inline `color-scheme`. User preference can be Light/Dark/System, saved as `zudo-doc-theme`.
- The internal runtime dispatches `color-scheme-changed` / `theme-preference-changed`, but do not present private helper-file imports as public exported APIs. Prefer inherited CSS for the workshop shell and explicit preview state for the iframe.

The current docs CSS pipeline still uses Tailwind v4 and semantic tokens. Reproducing those old build imports in the ZFB v3 prototype is not implied by the visual integration request; verify the actual ZFB doc host separately.

Sources:

- [Content CSS](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/content.css)
- [Theme CSS](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/theme.css)
- [Current global CSS](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/src/styles/global.css)
- [ColorSchemeProvider](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/theme/color-scheme-provider.tsx)
- [Theme runtime](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/theme-toggle/color-scheme-sync.ts)

## 6. Existing HtmlPreview can inform specimen tooling

Built-in `HtmlPreview` already renders isolated iframe srcdoc previews with:

- 320px Mobile, 768px Tablet and 100%-of-parent Full presets.
- A horizontal resize handle.
- Optional source-code disclosure.
- Fixed or automatic height.
- Optional html/css/head/js and external resource inputs.
- `preflight={false}` to omit its default injected Tailwind reset.
- `showViewportControls={false}` / `showSource={false}` for custom surrounding UI.
- `loading="visible"` lifecycle deferral in its route-bound wrapper.

Important limits:

- “Full” is full parent width, **not fullscreen**.
- The preview's base canvas is white independent of docs theme. The generated design's mode must be set inside its own document.
- `fullHeight` needs an explicit height; without it, auto height is disabled and the default 200px reservation remains.
- These are string-based HTML/CSS previews, not an automatic arbitrary Preact-app integration.
- Default script-bearing srcdoc is author-trusted; do not interpret this as an arbitrary user-code sandbox.
- Standard HtmlPreview can be a useful reference or specimen component. A complete workshop with editor state, selected elements and custom expansion needs additional authored UI.

Sources:

- [HtmlPreview docs](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/src/content/docs/components/html-preview.mdx)
- [PreviewBase](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/html-preview-wrapper/preview-base.tsx)
- [HtmlPreview wrapper](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/html-preview-wrapper/html-preview-wrapper.tsx)
- [HtmlPreview srcdoc implementation](https://github.com/zudolab/zudo-doc/blob/337b9f110793dccb4759bddd5273eab38cd9d2f0/packages/zudo-doc/src/html-preview-wrapper/html-preview.tsx)

## 7. Recommendation for /docs/playground/ prototype

The following is a proposed product composition, not a claim of existing one-call integration:

1. Register /docs/playground/ as a discoverable docs entry.
2. Use `wide:true`, `hide_sidebar:true`, `hide_toc:true` for the working page. This preserves native header/mobile navigation/breadcrumb while giving the actual editor the width. The referenced demo uses a visible TOC only to explain its layout; the workshop can intentionally differ.
3. Keep one compact docs H1 and short lead. Put preset selection and all workshop state in the content area.
4. Scope editor chrome; isolate the rendered design specimen in a local iframe.
5. Provide normal embedded view and a local “Expand workspace” mode. Clearly treat expansion as new workshop behavior, not an existing zudo-doc setting.
6. On mobile, use a top-level Preview/Edit switch or stacked sections, retain the doc hamburger, and avoid two simultaneous navigation drawers.
7. Add a static useful fallback and confirm hydration on cold load, soft navigation into the route, away/back, and the mobile route.
8. Do the final ZFB v3 integration against the actual doc host and resolved versions. Current zudo-doc's ^2.22.1 peer requirement and experimental custom-island scanner contract are the concrete remaining implementation uncertainties.

## Live URL

Requested guide: https://zudo-doc.takazudomodular.com/docs/guides/layout-demos/wide/

Commit: https://github.com/zudolab/zudo-doc/commit/337b9f110793dccb4759bddd5273eab38cd9d2f0
