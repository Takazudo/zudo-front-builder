# ZFB docs integration research — round 2

## Inspected revisions

- ZFB main: **09a9f9b38f2aae922ebd32128fcfb9a603ba7318**.
- Actual docs dependencies remain **zfb / runtime / md-wasm / Cloudflare adapter 2.20.2**, **zudo-doc 5.27.0**, **Preact ^10.29.1**, `@takazudo/zdtp 0.8.2`.
- Pinned zudo-doc source inspected at tag **v5.27.0**, tree **50cbd5c6c9e5a795d72a74a855e105e4939d4eab**.
- Live Playground index and render page were verified through web search/open after the direct trailing-slash open initially failed. Existing live index lists renderHtml, compile, parseToAst and highlightCode. Web refs: `turn7view0`, `turn7view1` (root must reopen before final citation).

Sources: [docs package](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/package.json), [docs instructions](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/CLAUDE.md), [live index](https://zfb.takazudomodular.com/docs/playground/).

## Recommended native integration

Add the workshop as **/docs/playground/design-system/**, with Japanese counterpart **/ja/docs/playground/design-system/**. Use the existing document route and wide content shell; no custom router or whole-page replacement is needed.

Proposed new host files:

- `docs/src/content/docs/playground/design-system.mdx`
- `docs/src/content/docs-ja/playground/design-system.mdx`
- `docs/src/components/playground/design-system-playground.tsx`
- Optional sibling data/export/pure-model files under that component directory.

Use the existing frontmatter contract:

```yaml
---
title: Design System Playground
description: Choose a starting point, change its design decisions, and export an editable zudo-wind seed.
sidebar_position: 5
wide: true
hide_sidebar: true
hide_toc: true
---
```

The MDX body should have one short introduction and `<DesignSystemPlayground />`. The title is already emitted by zudo-doc from frontmatter; do not duplicate an h1 or global product header inside the workshop.

Sources: [render page](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/content/docs/playground/render.mdx), [compile page](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/content/docs/playground/compile.mdx).

## External component registration and hydration

The established integration seam is `docs/zfb.config.ts:80`:

```ts
chromeBindingsModule: "./src/chrome-bindings.tsx"
```

`docs/src/chrome-bindings.tsx` statically imports the component modules and registers wrappers through `defineChromeBindings({ mdxExtras: {...} })`. Mirror the existing wrappers:

```tsx
import DesignSystemPlayground from "./components/playground/design-system-playground";

const DesignSystemPlaygroundIsland = () =>
  Island({ when: "visible", children: <DesignSystemPlayground /> });

// Add alongside the existing mdxExtras, preserving them:
DesignSystemPlayground: DesignSystemPlaygroundIsland
```

The client component follows this host's Preact convention:

```tsx
/** @jsxRuntime automatic */
/** @jsxImportSource preact */
"use client";
```

Existing route stubs already statically import `src/chrome-bindings` in addition to the virtual module. That edge is essential because the current island scanner cannot traverse only the virtual import to find disk-based client components. Adding a static import to chrome-bindings preserves this path; no route-stub edits should be necessary.

**Distinguish host and export runtime:** docs still use Preact/Tailwind. The downloadable seed can target current zudo-wind/zudo-react and retain native `class` attributes. Do not convert the whole docs host to new engines to embed the prototype.

Sources: [bindings](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/chrome-bindings.tsx), [config](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/zfb.config.ts#L69-L80), [default route](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/pages/docs/%5B%5B...slug%5D%5D.tsx), [client example](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/components/playground/render-playground.tsx).

## Actual native width and layout

In the pinned zudo-doc 5.27.0 package:

- `wide` maps to `contentWide` and sets `data-zd-wide` on `.zd-doc-content-band`.
- The wide rule is **`max-width: clamp(50rem, 92.5vw, 120rem)`**. This is a max-width on a `w-full` band, not a mobile min-width.
- The main element has `min-w-0`, `px-hsp-xl py-vsp-xl lg:px-hsp-2xl lg:py-vsp-2xl`: 24px horizontal / 40px vertical padding, desktop 32px horizontal / 56px vertical.
- The document article remains `class="zd-content max-w-none"`.
- Header, breadcrumb, footer and package controls remain present. Sidebar and both desktop/mobile TOC are hidden by the flags.
- Standard hide-sidebar content without `wide` is capped at 80rem; the wide rule intentionally overrides that cap.

For the prototype this means a document header leading into a wide workshop surface. Keep the workshop's local navigation concise; avoid nesting another full app header above the native document title.

Sources: [pinned doc layout lines 435–460](https://github.com/zudolab/zudo-doc/blob/v5.27.0/packages/zudo-doc/src/doclayout/doc-layout.tsx#L435-L460), [wide CSS lines 329–355](https://github.com/zudolab/zudo-doc/blob/v5.27.0/packages/zudo-doc/src/features.css#L329-L355), [frontmatter schema](https://github.com/zudolab/zudo-doc/blob/v5.27.0/packages/zudo-doc/src/docs-schema/index.ts#L78-L80).

## Native styles the workshop can reuse

Use host styles for workshop controls and keep edited design variables scoped to the preview.

| Purpose | Existing host vocabulary |
| --- | --- |
| Colors | `bg-bg`, `bg-surface`, `text-fg`, `text-muted`, `border-muted`, `bg-accent`, `hover:bg-accent-hover` |
| Code display | `bg-code-bg text-code-fg font-mono` |
| Typography | `text-micro`, `text-caption`, `text-small`, `text-body`, `text-title`, `text-heading` |
| Horizontal space | `hsp-2xs/xs/sm/md/lg/xl/2xl` = 2/6/8/12/16/24/32px |
| Vertical space | `vsp-3xs/2xs/xs/sm/md/lg/xl/2xl` = 4/7/14/20/24/28/40/56px |
| Corners | `rounded` = 4px; `rounded-lg` = 8px |
| Focus | Existing controls use `focus-visible:outline-2 focus-visible:outline-accent focus-visible:outline-offset-2` |

The defaults for semantic type are micro 12px, caption 14px, small 16px, body 19.2px, title 22.4px, heading 48px. Editor labels can follow the existing playground's `text-small`/`text-caption` instead of applying the larger prose body size everywhere.

`PlaygroundShell` is a Markdown input/output/run wrapper. Its native appearance is reusable, but its two editors and first-run WASM notice are not the right layout for a design workshop. `SamplePicker` and `OptionRow` provide smaller reusable control patterns.

The host `.zd-content` stylesheet styles descendant code, headings and lists, so use explicit scoped workshop rules where needed. The design preview should remain in its own document/iframe; writing seed variables to the docs root would change the host itself.

Sources: [existing shell](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/components/playground/playground-shell.tsx), [sample picker](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/components/playground/sample-picker.tsx), [pinned theme](https://github.com/zudolab/zudo-doc/blob/v5.27.0/packages/zudo-doc/src/theme.css), [host CSS import order](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/styles/global.css).

## Discovery, content wording and checks

1. Add a `Design System` child to the existing `Playground` item in `docs/zfb.config.ts`, preserving the four existing children and Index.
2. Add EN/JA MDX entries. Existing `CategoryNav category="playground"` auto-discovers child content via category metadata and sidebar order.
3. **Update both Playground index descriptions/intros.** They currently say every playground runs the same Rust pipeline. That claim does not apply to the authored-CSS workshop. Describe the broader set as browser tools for content and design, and keep WASM-specific claims on those individual pages.
4. Keep index and workshop cross-links as relative `.mdx` paths per docs instructions, allowing locale/base rewriting.
5. Existing test `page-title-layout.test.ts` asserts an exact five-child header object, so adding the new nav entry must update that expectation and the new-page hide-rails list.
6. Extend `docs/scripts/assert-island-markers.mjs` with the new route/default-export marker so emitted EN/JA pages and actual islands-bundle registration are both checked.
7. Relevant existing gates: `pnpm --filter docs check`, docs build, HTML validation and island markers. Browser verification should include direct navigation and arrival through the docs client router; the bindings/static import seam is specifically about real hydration.

Sources: [index](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/content/docs/playground/index.mdx), [JA index](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/content/docs-ja/playground/index.mdx), [layout contract test](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/components/playground/__tests__/page-title-layout.test.ts), [islands guard](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/scripts/assert-island-markers.mjs).

## Verification boundary

Read-only GitHub source inspection and web retrieval only. No repository mutations, browser UI actions, Site lifecycle or build/compile execution.

