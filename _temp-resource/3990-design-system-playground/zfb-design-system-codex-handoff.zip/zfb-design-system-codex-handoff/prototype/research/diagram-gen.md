# Round 2 reference research: zudo-diagram-gen inside zudo-doc

Read-only source review on 2026-10-07. No repository writes, builds, browser interactions, or deployment were performed for this research.

## Main finding

zudo-diagram-gen provides a direct precedent for a full interactive tool living inside the documentation site. It uses a normal `/docs/` MDX route with a wide content area, a registered custom component, and a small client wrapper around an independently mountable application. Its embedded mode adopts the documentation chrome's design and removes duplicate app branding/navigation. The tool's subject remains independently controlled.

The strongest adaptation for the accepted workshop is: **keep the preset → playground → starter flow as in-content tool navigation; let zudo-doc own the page title, site header, search, appearance menu, footer, and documentation navigation.** Keep the designed seed previews isolated from the tool controls.

## Snapshot and version boundary

Reviewed commit: [`5153aa8c9097137cb968f620141e5e3d2d46c1c5`](https://github.com/Takazudo/zudo-diagram-gen/commit/5153aa8c9097137cb968f620141e5e3d2d46c1c5), committed 2026-10-05. Its subject is the merge of zfb v3 support for generated diagram sessions.

This does **not** mean the embedded documentation host has migrated. The root [package.json](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/package.json) pins zfb/zfb-runtime `2.21.1`, zudo-doc `5.27.0`, Preact `10.29.2`, and Tailwind `4.2.0`. The [migration note](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/src/content/docs/changelog/2026-10-05-zfb3-sessions.mdx) explicitly defers documentation showcase migration. The diagrams engine [package contract](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/packages/diagram-gen/package.json) accepts zfb `^2.21.1 || ^3.2.0`, with Preact optional.

Therefore, reuse the architectural pattern and embedded behavior. Verify wrapper/hydration APIs against the current ZFB documentation stack before presenting them as ready-to-copy integration code.

## Actual integration path

### 1. Ordinary MDX supplies the route and layout intent

[`src/content/docs/workbench/index.mdx`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/src/content/docs/workbench/index.mdx) contains:

```mdx
---
title: Diagram workbench
description: Compare SVG directions and try the review controls in a complete example session.
wide: true
hide_sidebar: true
hide_toc: true
---

Explore the tone exploration session. …

<DiagramWorkbench dataUrl="/workbench-data/tone-exploration.json" />
```

These are three independent frontmatter choices. The generated examples index uses `wide: true` without hiding the sidebar; full interactive workbench pages additionally hide both sidebar and TOC. There is no hand-built parallel website layout for these routes.

For the workshop, the analogous page can retain a short introduction and related documentation links, then allocate the wide region to the tool. The editable-control sidebar belongs to the workbench; keeping a second documentation sidebar beside it would reduce the useful preview area.

### 2. Chrome bindings expose the component to content

[`src/chrome-bindings.tsx`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/src/chrome-bindings.tsx) registers the custom tag:

```tsx
export const chromeBindings = defineChromeBindings({
  mdxExtras: {
    DiagramWorkbench: ({ dataUrl }: { dataUrl: string }) =>
      Island({ when: 'visible', children: <DiagramWorkbench dataUrl={dataUrl} /> }),
  },
});
```

[`zfb.config.ts`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/zfb.config.ts) passes `chromeBindingsModule: './src/chrome-bindings.tsx'` into `zudoDoc()`, enables `strictContentBridge`, and leaves site-wide search, appearance, GitHub links, header navigation, and footer under the host configuration. `designTokenPanel` is disabled in this reference host; the embedded tool is separate from that documentation feature.

### 3. The catch-all route keeps the client component discoverable

[`pages/docs/[[...slug]].tsx`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/pages/docs/%5B%5B...slug%5D%5D.tsx) uses `createRouteContext`, `createChrome`, and the package's generated route/chrome virtual modules. It delegates rendering to `renderDocPage()`.

It also has the explicit side-effect import `import '../../src/chrome-bindings';`, with a comment saying this keeps the client island statically reachable by zfb's island scanner. Do not assume that registering a tag through an indirect runtime map alone proves the client bundle will contain it. This is a specific build integration point to check in the target stack.

### 4. A small wrapper owns loading and lifecycle

[`src/components/diagram-workbench.tsx`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/src/components/diagram-workbench.tsx) is a `'use client'` Preact component. It imports `mountDiagramApp` and package CSS, creates a container ref, fetches the JSON with an `AbortController`, reports loading/error status, and mounts only after the data and root are available. Effect cleanup aborts the fetch and invokes the returned disposer.

The package's [public mount type](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/packages/diagram-gen/client/mount.d.ts) is small:

```ts
mountDiagramApp(root: HTMLElement, data: GalleryData,
  options?: { embedded?: boolean }): () => void
```

The workshop can use a corresponding root-scoped mount contract, with a wrapper appropriate to the target renderer. Round 1's whole-document script should not simply run against the docs document: selectors, events, dialogs, URL handling, and teardown should be owned by the workshop root.

## What embedded mode changes

The implementation is in [`client/mount.mjs`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/packages/diagram-gen/client/mount.mjs) and the embedded section of [`client/app.css`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/packages/diagram-gen/client/app.css).

| Concern | Observed behavior | Workshop adaptation |
| --- | --- | --- |
| Ownership | Adds `.dg-app` / `data-embedded` to the passed container; queries are root-scoped | Give the workshop a mount root and scoped selectors |
| Site identity | Hides its brand, site links, sidebar footer, and independent UI-theme switch | Remove the round-1 duplicate brand/header/footer inside docs |
| Host appearance | Observes host `data-theme` / `class`; updates tool UI theme | Workshop controls follow docs appearance |
| Subject appearance | Keeps artwork theme separate from UI theme | Preserve each seed preview's own colors when docs switch theme |
| Dimensions | Embedded root/layout use `min-height: 0`, root uses `width: 100%` / `min-width: 0` | Size to available content space; remove outer full-viewport assumptions |
| Tokens | Maps `--dg-*` to docs spacing/type/radius/`--color-zd-*` roles | Use a bounded adapter for tool chrome; keep exported seed tokens separate |
| Visual treatment | Transparent surrounding surfaces, reduced duplicate headings, no card shadows | Let the workbench read as part of the documentation |
| URL ownership | `updateHash()` returns immediately when embedded | Do not overwrite docs anchors with `#start` / `#playground` routing |
| Keyboard | Shortcuts are scoped to the root and ignore host focus/editable controls/dialogs | Docs search and navigation retain their own interactions |
| Cleanup | Removes listeners, observers, timers, object URLs and owned DOM state | Support navigation away and clean remounting |

The CSS deliberately overrides host prose/reset behavior only under `.dg-app.dg-app`, rather than broadly resetting the docs page. The exact host token names in this old stack need rechecking; they are not a current zudo-wind contract.

The embedded diagram stage uses a bounded height (420px normally, 310px below 720px; comparison stages smaller). These are reference product choices, not required workshop dimensions. The important pattern is a content-sized outer tool with deliberately sized inner previews.

## Build and asset handling

[`scripts/build-showcase.mjs`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/scripts/build-showcase.mjs) validates/loads source sessions and generates:

- `public/workbench-data/*.json` for the wrapper to fetch.
- Wide MDX workbench/example pages that refer to those JSON URLs.
- Small SVG thumbnails under `public/previews/`.
- Generated site metadata for the host.

`build` prepares these assets before `zfb build`. [`scripts/dev.mjs`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/scripts/dev.mjs) does initial preparation and watches example/tone/client sources while delegating the server to zfb. The browser gets prepared data, not filesystem-reading engine modules. Artwork SVG strings are rendered through isolated image data URLs, preventing ID/style collisions with the host and each other.

The workshop's presets are small enough to bundle directly; a fetch-and-generation pipeline is optional, not a requirement to copy. If data becomes large or separately authored, the same static-data approach is available. Keep the three existing seed exports generated from the same state/model as the live specimens.

`src/styles/global.css` imports docs styles and the package's scoped app CSS; the client wrapper also imports that CSS. This demonstrates explicit build reachability, but does not prove duplicate imports are necessary in the target stack.

Standalone exports are another route through the shared viewer. [`src/render.mjs`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/packages/diagram-gen/src/render.mjs) embeds CSS, script, and safely serialized JSON for offline/generated sessions. That raw-HTML session path is not the docs MDX embedding mechanism and should not replace the normal docs route.

## Bounded round-2 UX recommendation

1. Add one documentation page, such as the proposed `/docs/playground/design-system/`, with host title/breadcrumb and a short introduction. Use the wide layout and hide TOC/sidebar for the active tool.
2. Preserve Starting point / Playground / Starter demo as compact in-content navigation. Keep Everyday initially selected and retain Editorial, Workbench, and all existing exports.
3. Remove duplicate global branding and large standalone introductory spacing. Put preset selection, current changes, Reset, and Export in one compact tool header.
4. Style editor controls and tool navigation with the docs design. Keep the sample website preview inside its existing isolated document so users can distinguish the tool from the design they are editing.
5. Preserve the role inspector and short contextual rules. Place longer “how it works” prose below the tool or behind a small help affordance; do not rebuild a second docs sidebar inside the workshop.
6. Keep the initializer concept explicitly proposed. This round establishes how the playground lives in docs, not that the production initializer has gained seed selection.

No replacement of the accepted workflow is needed. The change is its host relationship, chrome, and integration boundary.

## Existing verification evidence to adapt

The repository contains source tests for embedded host-theme following, independence of artwork theme, shortcut ownership, idempotent dispose, and remounting in [`test/ui.test.mjs`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/test/ui.test.mjs). Its [`check-site-browser.mjs`](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/scripts/check-site-browser.mjs) exercises docs routes, hydration, 1280/390 widths, host search versus app shortcuts, copy/download, and light/dark/system synchronization.

These are useful test intents; this research did not run them. Also, the reference host has `dynamicPageTransition: false`, so its configuration is not proof that the target site's client navigation/remount lifecycle works without additional verification.
