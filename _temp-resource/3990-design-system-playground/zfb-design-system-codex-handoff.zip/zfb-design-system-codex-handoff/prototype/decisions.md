# Design decisions and review state

## Decision record

| State | What it covers |
| --- | --- |
| **Accepted from round 1** | A seeded first experience; three editable examples; connected page, component, and foundation views; role inspection; a starter that explains its choices; exports that retain usage rules. |
| **Accepted in round 2** | Placement inside the ZFB docs Playground, native-looking documentation chrome, a wide tool page, compact local navigation, host-theme adaptation, and preservation of workshop state during host navigation. |
| **Superseded for this review** | The standalone workshop's separate site header/footer and global hash navigation. Their round-1 implementation remains available at `/r1/` for comparison. |
| **Pending** | Production component registration and hydration; integration with the actual docs build; compiler-backed export validation; initializer design-seed selection. Round 2 was accepted on 2026-10-07. Implementation and its verification remain outstanding. |

## Why the workshop now lives in docs

The documentation should give users a usable starting design and explain how it works in one place. The Playground index makes the tool discoverable. The wide page hides documentation side rails while the workshop is active, leaving room for its editor and preview. Starting point, Playground, and Starter demo remain local tool views rather than becoming a second website navigation system.

The precedent is [zudo-diagram-gen's wide workbench MDX page](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/src/content/docs/workbench/index.mdx), its [custom component binding](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/src/chrome-bindings.tsx), and its [embedded tool styling](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/packages/diagram-gen/client/app.css). Those sources inform the proposed boundary; this prototype does not install that integration.

## Keep the tool and the design distinct

The documentation appearance controls the workshop chrome. Seed colors, type, spacing, and shape remain inside separate preview documents. Switching the docs to dark mode therefore does not silently redesign an Everyday or Editorial seed.

The workshop now has a root-scoped mount/dispose interface. Local tabs do not claim the host's URL hash. The shell captures state before disposal and restores it when reopening the tool. This prepares an integration boundary without claiming that the actual zudo-doc component lifecycle has been verified.

Usage rules remain part of the export. This follows CSS Wisdom's [design-tone guidance](https://github.com/Takazudo/zudo-css-wisdom/blob/6f7c31b2baa70bd188aea31ecbd5ac08ee420065/src/content/docs/design-principles/design-tone-spec-for-ai.mdx): token values need adjacent guidance about where and how to use them.

## Implementation follow-through

The wide docs page, compact navigation, and relationship between host and preview are accepted. Validate the proposed adapter against the target docs stack, compile the exported utility vocabulary, and improve the real starter. Initializer selection remains a separate proposed feature; site structure and design seed should remain independent choices.

The original requirement to improve actual bundled starter demos remains part of the accepted implementation scope; the workshop’s Starter demo view alone does not complete it. The actual initializer seed selector remains a separate future feature.
