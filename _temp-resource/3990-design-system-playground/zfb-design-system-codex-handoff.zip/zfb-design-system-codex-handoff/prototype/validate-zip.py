from pathlib import Path
import zipfile, json, hashlib, sys

base = Path(__file__).resolve().parent / 'seeds'
node_report = json.loads((base / 'node-validation.json').read_text())
source_path = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else base.parent / 'source/dist/workshop.js'
current_sha = hashlib.sha256(source_path.read_bytes()).hexdigest()
assert node_report['sourceSha256'] == current_sha, 'workshop.js changed after generation; regenerate before validating'
records = []
for archive in sorted(base.glob('zudo-wind-*-seed.zip')):
    preset = archive.name.removeprefix('zudo-wind-').removesuffix('-seed.zip')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None, archive.name
        assert len(z.infolist()) == 5
        assert len(z.namelist()) == len(set(z.namelist()))
        files = []
        for info in z.infolist():
            assert not Path(info.filename).is_absolute() and '..' not in Path(info.filename).parts
            assert info.flag_bits & 0x800, 'UTF-8 ZIP filename flag missing'
            data = z.read(info.filename)
            data.decode('utf-8', 'strict')
            assert data == (base / preset / info.filename).read_bytes(), info.filename
            files.append({'name': info.filename, 'utf8': True, 'crc32': f'{info.CRC:08x}', 'byteEqualToGeneratedFile': True})
        records.append({'archive': archive.name, 'testzip': 'passed', 'entries': files})
report = {'reader': 'Python zipfile', 'archiveCount': len(records), 'sourceSha256': current_sha, 'archives': records}
assert report['archiveCount'] == 3
(base / 'zip-validation.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'archiveCount': len(records), 'entryCount': sum(len(r['entries']) for r in records), 'allChecksPassed': True, 'sourceSha256': current_sha}, indent=2))
