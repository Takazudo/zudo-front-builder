# Accepted specification: zudo-wind onboarding, docs playground, and explanatory starters

## Status and goal

The maintainer accepted UI prototype round 2 on **2026-10-07**: “good. spec locked in.” Implement that direction in `Takazudo/zudo-front-builder`. Product implementation has not started. The private prototype models the documentation shell; it is not an actual ZFB docs build.

zudo-wind supplies a utility language without an implicit design system. That freedom currently makes the first experience harder than it needs to be. Give people a coherent starting design, show why its decisions work, and let them own and change the resulting files. Preserve the engine's preset-free contract: these are explicit, editable project choices, not hidden global defaults.

There are two required product outcomes:

1. A design-system playground embedded in the actual ZFB documentation.
2. Improved **real bundled starter demos** with a proper project-owned design-system example and short explanations. The documentation's Starter demo tab alone does not satisfy the original request.

This is one coordinated implementation task. Shared seed definitions and their exporter should precede the docs UI and starter consumers; then verify the integrated result. Codex Cloud is the requested destination. No separate ChatGPT Work step or private plugin installation is required.

## Accepted documentation experience

### Discovery and layout

- Add the design tool to the existing `/docs/playground/` index and Playground header navigation. Preserve renderHtml, compile, parseToAst, and highlightCode.
- The index presents a prominent **Design system playground** entry with three miniature starting designs and a clear **Open design playground** action. Explain choosing a design, changing its rules, and taking editable files into a project.
- Keep the ordinary documentation width policy on the index. Give the individual tool page `/docs/playground/design-system/` `wide: true`, `hide_sidebar: true`, and `hide_toc: true`.
- Use the real zudo-doc header, breadcrumb, frontmatter title, theme controls, search, locale navigation, and footer. The prototype's `docs-shell.js`, `docs-shell.css`, parallel static routes, and miniature search implementation are review scaffolding; production uses the host's existing equivalents.
- Revise the index's statement that every playground executes the Rust Markdown pipeline. The design preview uses authored CSS; do not imply it runs the compiler in the browser.
- Add the English and Japanese documentation pages, index wording and discovery entries according to the repository's locale conventions. The accepted prototype has English controls and bilingual specimens; full control localization is not a new requirement.

### Local views

Keep the compact three-view navigation inside the page: **01 Starting point / 02 Playground / 03 Starter demo**. The host supplies the h1; embedded sections start at h2. Local views must not take ownership of the documentation URL hash.

**Starting point**

- Everyday is the suggested initial choice. Editorial and Workbench remain visibly different complete examples of the same content.
- Show each design's miniature, name, short description, and traits. Selection is visible and accessible; **Make this design yours** opens the live Playground with that seed.
- Explain what a seed contains: foundations, a working example, usage rules, and editable files. Explain that values, names and rules become project-owned.
- Retain the explanatory path for people who already have a system. The initializer illustration distinguishes site template from design seed, including a no-seed concept. Do not present unimplemented CLI syntax as an available command.

**Playground**

- One shared design model drives controls, Page / Components / Foundations previews, Starter demo, usage rules, and exports.
- Preserve preset selection, edited-decision count, Reset, and Export this design.
- Color: primary-action color picker and hex field, semantic-role swatches, explanatory usage rule, and computed label contrast. Invalid/incomplete hex input must not corrupt the last valid design. A contrast readout is not a claim of complete accessibility certification.
- Typography: heading voice, body size, reading line height, and reading measure.
- Spacing: independent horizontal card padding, vertical grouping and section spacing. Keep column gutter and page-padding roles explicit rather than conflating all relationships in one spacing value.
- Shape: the shared corner rule for cards, fields and actions.
- Page, Components, and Foundations display the same design. Wide uses the available preview width; Phone uses a maximum width of 390px. Reflow the editing UI on small screens without horizontal page overflow.
- **Inspect roles** makes relevant rendered elements inspectable. Selecting one reveals the chain **value → semantic role → utility usage**, including primary action, body text, and group spacing. Provide keyboard-accessible role choices as well as pointer inspection.
- Preview-local anchors and demo interactions stay inside the specimen. Sample signup does not transmit or store data.

**Starter demo**

- Show a complete Fieldnotes-style example using the current design: header, introduction/action, content cards, form specimen, and a short “How this site is styled” section.
- Preserve toggleable explanatory notes and adjacent current usage rules. Explanations must track edited values, not stale preset defaults.
- Explain accent purpose, grouping/section relationships, independent horizontal spacing, type/reading rhythm, and the shared shape rule.
- Inspection mode must not leak from Playground into Starter or exported standalone demos.

### Host/theme/lifecycle boundary

- Documentation appearance affects the tool's controls. Seed appearance stays within its isolated preview document. Dark documentation must not silently redesign an Everyday or Editorial seed.
- Scope selectors and listeners to the component root. Keep specimen variables inside their preview document so host styles and seed styles cannot change one another.
- Use the existing supported client component/island registration path. The current host is Preact-based; keep that integration unless the separately owned migration has already landed.
- Implement explicit mount and idempotent disposal: remove owned DOM, abort listeners/tools, clear timers, close owned dialogs, revoke object URLs, and ignore asynchronous completion after disposal.
- Preserve design and local-view state when navigating from the workshop to the Playground index and returning in the same browser session. Save the snapshot before disposal and pass it when remounting. Test this through **native documentation navigation**, not only a mock shell. Persistence across reloads/accounts/devices is not required.
- The corrected wrapper sketch in the handoff includes snapshot retention. Its module lifetime still requires verification against the real host; use an appropriate host-owned in-memory store if necessary.

## Seed contract and accepted starting values

Seed definitions are ordinary project-owned choices. Use a shared definition or deterministic generation boundary so examples, rules and exports do not drift.

| Decision | Everyday | Editorial | Workbench |
| --- | --- | --- | --- |
| Primary accent | `#3159d8` | `#913b28` | `#cae887` |
| Background | `#f4f7fb` | `#faf8f2` | `#171e1b` |
| Surface | `#ffffff` | `#fffefa` | `#202a25` |
| Ink | `#17253c` | `#352b26` | `#e0e9df` |
| Muted | `#586882` | `#736457` | `#acbaac` |
| Border | `#d5deeb` | `#d9cdbd` | `#405047` |
| Heading voice | Sans | Serif | Monospace |
| Body size / line height | 16px / 1.65 | 17px / 1.8 | 16px / 1.55 |
| Heading size | 42px | 47px | 35px |
| Vertical group / section | 16px / 40px | 20px / 56px | 12px / 32px |
| Horizontal card padding / gutter | 24px / 16px | 30px / 20px | 18px / 12px |
| Corner radius | 8px | 0px | 3px |
| Reading measure | 60ch | 56ch | 64ch |

Accepted control ranges: body 14–20px; line height 1.4–2; vertical group 8–24px; vertical section 16–64px; horizontal card padding 12–36px; radius 0–18px; reading measure 42–72ch. Preserve the prototype's useful ranges unless a concrete accessibility or compiler constraint requires an explained adjustment.

Example chains are `--ds-brand` → `--ds-accent` → `bg-accent`, `--ds-font-body` → `text-body`, and a grouping value → `vsp-stack` → `gap-y-vsp-stack`. Keep horizontal roles (`hsp-*`) and vertical roles (`vsp-*`) explicit. Derive the on-accent foreground and current prose from current values. Do not restore a baked-in palette, spacing scale, or mandatory component library to zudo-wind.

### Five-file export

Export the current design as a local ZIP containing:

1. `design-system.css` — owned CSS variables.
2. `zfb.design.ts` — a wind configuration section to merge into an existing configuration, not a fake complete application.
3. `usage.tsx` — utility usage examples.
4. `DESIGN-NOTES.md` — usage rules that match the exported values.
5. `demo.html` — standalone authored-CSS specimen without inspection artifacts.

The export dialog previews these files, supports Copy file, and downloads the current seed. No account, backend service, API key, or direct project-file write is required. Reuse the actual generator for preview, output and validation. The prototype's export is source-reviewed only; the implementation must compile the configuration and utility examples through the actual target ZFB/Wind toolchain. Continuous browser-side Rust compilation is not required.

## Real starter work

Improve the current bundled visual starters in `crates/zfb/templates/basic-blog/` and `crates/zfb/templates/node-free/`, preserving their differing runtime contracts. Basic blog already contains `content/blog/styling-with-zudo-wind.md`; build on that existing explanation instead of adding a disconnected second guide.

- Give the normal first-run experience a coherent small design, using the accepted Everyday direction where appropriate. Starter-specific layout details may stay local.
- Ship the owned values and a short set of usage rules with the generated project. Demonstrate purpose-based color, independent spacing relationships, type roles and readable line length on its actual page(s).
- Preserve the existing starter's useful Markdown examples, routes and scaffold contracts. Do not replace the current starter wholesale with the workshop's static HTML just to match the preview.
- Keep Node-free's no-Node/no-install contract and its current static browser output for this change. It can demonstrate the same design philosophy through generated CSS and prose without adopting the interactive editor. This is a constraint on this starter change, not a claim that the platform cannot support islands.
- Preserve required smoke markers and make focused adjustments to affected assertions only when necessary for the accepted change. Do not weaken validation to conceal a regression.
- Update relevant EN/JA getting-started or starter guidance with links to the design playground and clear instructions for editing the owned design.

Adding a production initializer seed selector, a CLI flag, or all template×seed combinations is **deferred**. This does not defer improving the starter defaults themselves. Keep any initializer illustration honest about that boundary.

Current scaffold contracts to preserve:

- Basic blog: `/`, `/about`, flat `404.html`, the existing `hello-zfb`, `markdown-showcase`, and `styling-with-zudo-wind` post slugs, its working zudo-react theme behavior, and protected Markdown showcase features. Packed smoke/showcase checks require `basic-blog` and the seed title `Hello, zfb`.
- Node-free: `zfb.config.json`, no `package.json` or package install, `pages/index.tsx`, `pages/posts/[slug].tsx`, and Markdown content. Preserve `node-free`, `Hello, zfb`, `/posts/hello/`, and rendered `<strong>node-free</strong>` smoke evidence. An explicit wind section and generated CSS may be added without Node. Update the current README claim that the default emits no Wind stylesheet if the new starter intentionally adds one; keep the engine's empty-config/no-stylesheet contract intact.
- Templates are compile-time embedded by `crates/zfb/src/commands/new.rs`. Verify edited starters using a binary built from the implementation revision or its corresponding CI scaffold artifact. An older installed `zfb new` cannot verify changed template bytes.

## Integration map and dependency boundaries

Base is `main`, inspected at `09a9f9b38f2aae922ebd32128fcfb9a603ba7318`. Refresh before implementation.

The inspected documentation host pins zfb/runtime/md-wasm/Cloudflare adapter **2.20.2**, zudo-doc **5.27.0**, and Preact **^10.29.1**. The docs host and the generated Wind consumer are separate validation contexts.

The inspected root uses `pnpm@12.8.2` and Node `^22.18.0 || ^24.11.0 || >=26.0.0`. Keep the current lockfile and toolchain conventions. The docs tsconfig intentionally inlines the compatible configuration without `baseUrl`; do not restore the old inherited-baseUrl setup.

Expected integration points:

- `docs/src/content/docs/playground/design-system.mdx`
- `docs/src/content/docs-ja/playground/design-system.mdx`
- Both existing `playground/index.mdx` files and the appropriate category/header navigation.
- `docs/src/components/playground/design-system-playground.tsx` and a host-owned directory for the reusable model/mount/styles.
- `docs/src/chrome-bindings.tsx`: register through the existing `mdxExtras` and `Island` pattern; keep the client component statically reachable and its display name stable.
- `docs/zfb.config.ts`: preserve the existing `chromeBindingsModule` and update the Playground submenu.
- `docs/src/styles/global.css`: load scoped tool styles in the host's established order.
- Existing page-title/layout assertions and `docs/scripts/assert-island-markers.mjs`.

Use the actual documentation shell, not the prototype shell. The prototype's `window.mountDesignWorkshop` can become a named module export in the production copy. Refactor its internals to fit repository conventions while preserving accepted behavior.

Related issue **#3329**, the docs host migration, is open and separately gated. This task does not authorize completing that migration, changing its dependencies, or closing it. Add the new component to the current supported host. If the migration lands before implementation, adapt to that verified host instead of reintroducing its old renderer. Report any concrete incompatible dependency as a blocker and continue independent seed/starter work.

The historical Basic blog redesign **#2268** is closed; do not reopen or duplicate its previous Tailwind-era redesign. Preserve the current starter and apply the new project-owned design work to it.

## Verification and acceptance

### Development policy and dependency order

Inherit [CLAUDE.md's development strategy](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/CLAUDE.md#development-strategy-integrate-first-use-ci-to-find-regressions) and `.claude/references/development-planning.md`.

- **Integration parent:** the prepared `base/design-system-playground-r2` task branch, with its eventual implementation PR targeting `main`.
- **CI/fixing owner:** the Codex session's implementation manager. Child agents use cheap affected checks and local commits; only the manager pushes from the repository root. Batch heavy build/browser/compiler verification across integrated work and use the heavy guard when required.
- **Dependency DAG:** shared seeds/model/export contract → docs component; shared seeds/model/export contract → starter defaults; docs component → native routes/navigation/locale integration; docs integration + starter defaults + exporter → final confirmation. Serialize edits to shared seed definitions, template manifests, global styles and navigation/assertion files. Independent docs wording may proceed during a localized, tracked failure that it does not depend on.
- **Evidence:** record exact SHA, run/job links and actual outcomes. Diagnose red CI; continue independent work only when the failure is understood/localized and repair is owned. Pause an affected chain for unknown or foundational failures.
- **Completion:** reconcile required integrated evidence before declaring the task verified. Do not require repeated full cold Rust builds for every child edit or confuse an integration with verified completion.
- **Task-specific exception:** this handoff authorizes no PR merge or external publication. Leave the prepared PR open for review. The repo's integrate-first policy does not grant new merge permission for this handoff.

This stays a single bounded task because one shared design model serves a docs component and the two bundled starters, with one final integration/verification owner. It does not include an engine, docs-renderer, or publishing migration.

- [ ] EN and JA workshop routes build, register/hydrate the interactive component, and are discoverable from the real Playground navigation/index.
- [ ] The accepted wide layout, local views, three seeds, shared controls, role inspection, starter explanations and export behavior work in the real docs host.
- [ ] Existing Markdown playground routes, native search/navigation, theme controls, side-rail behavior elsewhere, and locale links remain functional.
- [ ] Native navigation away/back restores the current design/view with one live component and no duplicated listeners. Starter and exported demos do not inherit inspection mode.
- [ ] Desktop and phone/tablet layouts are usable; controls and role selection are keyboard-accessible; preview anchors remain contained; actual downloads and clipboard behavior are checked in a supported browser.
- [ ] The real generated Basic blog and Node-free experiences include owned design decisions and explanations while retaining their existing runtime/scaffold behavior.
- [ ] The five exported files agree with the current values/rules, archive checks pass, and the actual target compiler/build accepts the exported config and utility usage.
- [ ] Run the repository-required checks for the touched scope. At minimum, inspect and use the current docs check, guarded build, HTML/island assertions and relevant tests; run focused scaffold/compiler checks for the changed starter/export paths.
- [ ] Review the diff and current-head CI, fix change-related failures, and record exact commands, versions, source revision and outcomes. Failed, blocked and not-run checks remain distinct.
- [ ] Move lasting code/docs to their production paths and remove the temporary handoff directory before merge. Do not merge a resources-only delivery.

Producer verification already completed: browser interactions and responsive/theme/lifecycle checks on the authored prototype; all three seed ZIPs pass CRC and 15-file byte equality; standalone script syntax passes. **Not performed:** native ZFB docs integration/build/hydration or actual Wind compilation. See `prototype/QA-NOTES.md` for evidence and limits.

Current verification entry points (refresh their definitions in the checkout before running):

```sh
pnpm install --frozen-lockfile
pnpm docs:check
pnpm --filter docs test
pnpm docs:build
pnpm --filter docs check:html
pnpm --filter docs check:islands
```

The manager owns the guarded docs build, browser/visual pass, actual Wind compilation and starter build/smoke work. Relevant existing contracts include `crates/zfb/tests/end_to_end_basic_blog_build.rs`, `scripts/smoke-packed-clean-room.sh`, `tests/smoke/node-free/run.sh`, and `tests/smoke/node-free-ts/run.sh`. Use those scripts' documented arguments/environment and a binary from the implementation revision; do not invent a cheap test that only checks template text instead of emitted behavior. Batch required heavy work rather than running it once per child edit.

## Non-goals and permissions

No universal component library, unrestricted AI generator, account/cloud persistence, per-seed dual themes, external package integrations, or real initializer selector is implied. zudo-sg, zudo-design-token-panel/roken-panel, CSS Wisdom and diagram-gen inform the design; installing all of them is not required. The R1 comparison page and prototype-only status/search/about scaffolding do not become production features.

The Codex implementation may edit in-scope source/docs/tests, commit and push its task branch, and create or update the implementation PR targeting `main`. Merge, deployment and package publication are not authorized. Leave the delivery issue open while the PR is unmerged or required work remains. Preserve unrelated migration issues and PRs.

## Reference sources

- [ZFB current bindings](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/chrome-bindings.tsx)
- [ZFB existing wide playground](https://github.com/Takazudo/zudo-front-builder/blob/09a9f9b38f2aae922ebd32128fcfb9a603ba7318/docs/src/content/docs/playground/render.mdx)
- [zudo-doc wide layout](https://zudo-doc.takazudomodular.com/docs/guides/layout-demos/wide/)
- [Diagram-gen embedded wrapper](https://github.com/Takazudo/zudo-diagram-gen/blob/5153aa8c9097137cb968f620141e5e3d2d46c1c5/src/components/diagram-workbench.tsx)
- [CSS Wisdom](https://github.com/Takazudo/zudo-css-wisdom)
- [Separate docs migration](https://github.com/Takazudo/zudo-front-builder/issues/3329)
- [Historical starter redesign](https://github.com/Takazudo/zudo-front-builder/issues/2268)
