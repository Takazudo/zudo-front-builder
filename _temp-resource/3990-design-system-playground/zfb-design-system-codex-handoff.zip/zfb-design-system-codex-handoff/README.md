# Codex Cloud handoff — accepted round 2

Issue: https://github.com/Takazudo/zudo-front-builder/issues/3990

Repository: https://github.com/Takazudo/zudo-front-builder

Accepted on 2026-10-07. **Read `ACCEPTED-SPEC.md` first.** It records the accepted documentation playground, project-owned seeds, real starter updates, dependency order, constraints and verification. The live prototype's interface is locked; its authored documentation shell is a reference for the real host integration.

## Resources

- `prototype/zfb-design-workshop-r2.html` — complete single-file interactive reference.
- `prototype/source/` — editable Vite source for the exact accepted UI, including the preserved R1 reference.
- `prototype/screenshots/` — desktop, responsive and theme-separation captures.
- `prototype/seeds/` — Everyday, Editorial and Workbench exports, with actual generator verification reports.
- `prototype/integration/README.md` — source-backed MDX, module and client-component integration sketches. The handoff correction includes snapshot retention during native docs navigation; typechecking and native lifecycle verification are still required.
- `prototype/research/` — ZFB, zudo-doc and diagram-gen research.
- `prototype/QA-NOTES.md` — what passed and what was not run.

To review the editable app, run `npm ci` and `npm run dev` inside `prototype/source/`. This optional reference server is Vite; production implementation belongs in the actual ZFB repository.

## GitHub continuation

The accepted bundle is retained on `base/design-system-playground-r2` under:

`_temp-resource/3990-design-system-playground/`

The issue links the prepared draft PR and pinned resource commit. Reuse that PR for implementation; do not merge it as a resource-only delivery. Extract the ZIP to an ignored temporary directory while reviewing it. Move lasting code, documentation and tests into their proper repository paths, then delete `_temp-resource/3990-design-system-playground/` from the implementation diff before merge.

The full issue is readable without this archive. Exact source and screenshots are useful original references; no external binary asset is indispensable to the specification. A missing archive does not justify stopping independent implementation from the accepted spec.

## Scope and authority

Implement the docs playground **and** the actual Basic blog / Node-free starter improvements. Keep the real initializer seed picker deferred. Keep docs-host migration issue #3329 separate. Preserve the current host package pins unless that independently verified migration has already landed.

Implementation, scoped checks, commits, pushes, and updating the prepared PR are authorized in the receiving Codex task. Merge, deployment, and package publication are not. Leave issue #3990 and the PR open for review until delivery and its required verification are complete.

No ChatGPT history, private plugin, or access to the private hosted preview is required. The issue and this bundle contain the specification and original reference files.
